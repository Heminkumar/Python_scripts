'''
Subject: Generate dataStorage zip file with tpmsData.csv and sysOtherData.csv and package it to zip
Author: Hemin Patel (Date:- 9th march,2020)
Example:-R03_08_00_05__CG_1583910111.zip
'''

import sys
import os
from zipfile import ZipFile
import time;

def generate(time_val):
    # Create file append format e.g "__CG_1583663261.zip"
    ext = str('.')+'zip'
    y = "{}{}".format(time_val,ext)
    return "{}{}".format('__CG_',y)

def zip_create(filename):
    #create a ZipFile object
    zipObj = ZipFile(filename,'w')
    # Add multiple files to the zip
    zipObj.write('error.json')
    # close the Zip File
    zipObj.close()

def ZipFile_move():
    try:
        os.system("rm -rf zip*")
    except:
        print("Folder is not present...")
    finally:
        # zip folder create and move it to folder
        os.mkdir('zip_' + time.strftime("%Y_%m_%d-%H_%M_%S"))
        os.system('mv R0* zip*')

def main():
    if len(sys.argv) < 2:
        print("You must provide version of the GW.")
        exit()
    else:
        # take version from arg1 and append to list and format it
        version = sys.argv[1]
        list1 = version.split('.')
        # take current time
        time_val = int(time.time())
        # take blank list and version format with first '0'
        pad_list = []
        for i in list1:
            s1 = '0'+i
            pad_list.append(s1)
        # filename blank list and append with zip file name    
        filename = []
        # Generate 1500 zip files
        for i in range(0,1500):
            x = generate(time_val) 
            FN = 'R'+pad_list[0]+'_'+pad_list[1]+'_'+pad_list[2]+'_'+pad_list[3]+x
            filename.append(FN)
            time_val = time_val + 1
        # Zip file create for all fileName
        for i in filename:
            zip_create(i)
        # Move Datastorage zip file 
        ZipFile_move()

if __name__ == '__main__':
   main()
   
